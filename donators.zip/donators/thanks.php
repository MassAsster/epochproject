<?php
include ('style.php');
require('config.php');
?>
<?php		
if (isset($_GET['thankyou']) && $_GET['thankyou']) {

echo "<TABLE BORDER=1 style='width:400px'><th bgcolor='#003399'> <center><h3><font color=#ffffff>Success</font> </h3><TR><TD>
<center><table border=0 bgcolor='#ffffff'><td align=center>
<td>";
Echo "Transaction Complete<P>";
echo "Please Close your Browser";

}
?>



  </TD></TR></TABLE> 
 
