
<TITLE>Donation Manager</TITLE><meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" ><style type="text/css">
<!--
body,td,th {
	color: #000;
	font-size: 18px;
}
body {
	background-color: #424242;
	background-image:url(images/bg.png);
}
-->
</style></HEAD>
<BODY><center>
<P>
<BODY link="#606060" vlink="#606060" alink="#606060">
<?php
error_reporting(0);
?>
