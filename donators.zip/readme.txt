use the SQL files to install the needed tables into your database

please follow the PDF instructions